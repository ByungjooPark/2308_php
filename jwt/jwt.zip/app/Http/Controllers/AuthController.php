<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Exception;

class AuthController extends Controller
{
    /**
     * 로그인처리
     * 
     * @param Illuminate\Http\Request $request 리퀘스트 객체
     * @return string json 엑세스토큰, 쿠키httponly 리플래쉬토큰
     */
    public function login(Request $request) {
        // DB 유저정보 획득
        $userInfo = User::where('u_id', $request->u_id)
                    ->where('u_pw', $request->u_pw)
                    ->first();

        // 유저정보 NULL 확인
        if(is_null($userInfo)) {
            throw new Exception('E20');
        }
        // 토큰생성

        // 리플래쉬 토큰 DB 저장

        // 리턴
    }
}
